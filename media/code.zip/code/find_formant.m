%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%												%
%												%
%       Code Created By: Adrian A. Galindo		%
%												%
%           adrian.galindo@gmail.com			%
%												%
%               281-891-3532					%
%												%
%       For: Rice University | 301 Project		%
%												%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [ max_freq_mag_array ] = find_formant( windows,window_length,index_to_freq )
%find_formant finds the formants in each window in windows array where each
%window is of length window_length
%   Detailed explanation goes here
%   Windows should be an array of ffts - each a window of a larger signal
%   index_to_freq is what correlates array index within each window to actuall
%   freq instead of a random index

format long;
%that's:
% f1_bottom = nearest available frequency for formant 1
% i_f1_bottom = index of nearest available frequency for formant 1
[f1_bottom,i_f1_bottom] = find_value_nearest(index_to_freq,200);
[f1_top,i_f1_top]       = find_value_nearest(index_to_freq,700);%Hz

[f2_bottom,i_f2_bottom] = find_value_nearest(index_to_freq,800);
[f2_top,i_f2_top]       = find_value_nearest(index_to_freq,3000);
max_freq_mag_array=[];

for this_window_index = 1:window_length:length(windows)
    
    %Need to extract 1 window at a time: 
    this_window = windows(this_window_index:this_window_index+window_length-1);
    
    %Now we extract the (large) segments where we think the formants should be:
    first_formant_segment = this_window(i_f1_bottom:i_f1_top);
    constantIndexOffset=1;
    found_peak=0;
    %[f2_mag,f2_index] = max(this_window(i_f1_bottom:i_f1_top));
    while found_peak == 0
        
        second_formant_segment = this_window(i_f2_bottom:i_f2_top);
        [f2_mag,f2_index] = max(second_formant_segment);
        test_freq_index = f2_index + i_f2_bottom-1;
        test_window_segment = this_window(test_freq_index-constantIndexOffset:test_freq_index+constantIndexOffset);
        test_window_segment_high = this_window(test_freq_index:test_freq_index+constantIndexOffset);
        test_window_segment_low = this_window(test_freq_index-constantIndexOffset:test_freq_index);
               
    if(max(test_window_segment) == f2_mag)
            found_peak = 1;
    elseif(max(test_window_segment_high) > f2_mag)
            found_peak = 0;
            i_f2_top = i_f2_top - 2*constantIndexOffset;
    else(max(test_window_segment_low) > f2_mag);
            found_peak = 0;
            i_f2_bottom = i_f2_bottom + 2*constantIndexOffset;
    end
    
    end
    %Now we find the max within the ranges from above.
    
    % Remember: max() returns [max_value,max_value_index]
    
    [f1_mag,f1_index] = max(first_formant_segment);
    
    f1_freq = index_to_freq(f1_index + i_f1_bottom-1);
    f2_freq = index_to_freq(f2_index + i_f2_bottom-1);
    
    %Append to the return array
    %[f1_freq f2_freq f1_mag f2_mag]
    max_freq_mag_array = [max_freq_mag_array;f1_freq f2_freq f1_mag f2_mag];
    

end

end

