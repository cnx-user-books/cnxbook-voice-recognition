function [ nearest_value,nearest_value_index ] = find_value_nearest( vector,search_value )
%UNTITLED2 Summary of this function goes here
%   Vector is the vector through which we will be searching
%   Value is the value is value we will be looking for in vector
%   This program attempts to minimize the error between an item in vector
%   and the value by choosing the item in vector nearest vector.
%
%   

[~,nearest_value_index] = min(abs(vector-search_value));

nearest_value=vector(nearest_value_index);

end

