%function [ output_args ] = untitled( input_args )
function [magRule,percentError,finalAnswer] = formants(fileName,winSize,actualVowel)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

audioData=wavread(fileName);%[GB] Gets data from the 
out=audioData;%[GB]Output variable
windowSize=winSize;%[GB] Window size for the fft
filterOrder=10; %[GB] Order of the filter
[numRows,numCols]=size(audioData); %[GB]Gets the size of the audio vector. This will be used to figure out how many windows are necessary
stepSize=windowSize/2;%[GB]Step size
numWindows=floor(numRows/stepSize)-1; %[GB]Caclulates the number of windows necessary by dividing the number of data samples by the step size. This assumes 50% overlap
windows=[];
% Windows and fft's the signal%
for step=0:numWindows-1
    N1=1+stepSize*step;%[GB]N1 represents the beginning index of the window 
    N2=N1+windowSize-1;%[GB]N2 demarcates where the window ends
    windowedSignal=audioData(N1:N2);
    %bandFilter=bpass;%[GB]Gets band pass filter previously designed
    lowFilter=lpass;%[GB]Gets lowpass filter
    filtSignal=filter(lowFilter,windowedSignal.*hamming(windowSize));%[GB]Applies the butter filter to the signal
    highPassButter=butterWorth;%[GB]Gets the high pass butterworth filter%
    filtSignal=filter(highPassButter,filtSignal);%[GB]Applies the butter filter to the LPF signal
    NFFT = 2048; %[GB] Next power of 2 from length of y
    transform=fft(filtSignal,NFFT)/1024;%[GB] Transform from discrete values to the frequency domain
    transform=transform';

    windows=[windows,abs(transform)];
    freq = 44100/2*linspace(0,1,NFFT/2+1);%[GB]Frequency index
     
    %filtTransform=filter(bandFilter,transform);%[GB]Uses the bandpass filter to filter signal
    
    %filtTransform=filter(lowFilter,transform);%[GB]Uses the lowpass filter to filter out any high frequency components of the signal   

    if(step==90)
        out=windowedSignal.*hamming(windowSize);
            % Plots Frequency Response
        %plot(freq,2*abs((1:transform(NFFT/2+1))))
        plot(freq,2*abs(transform(1:NFFT/2+1)))
        title('Vowel [i] as in "heed")')
        xlabel('Frequency (Hz)')
        ylabel('|X(f)|')
        %plot(abs(filtTransform));
        %xlabel('Frequency(kHz)')
        %ylabel('Response')
    end
end

%[GB] Gets the formant and magnitude matrix from Adrian's code
formantMagMatrix=find_formant(windows,NFFT,freq);%[GB] Gets formant and magnitude results. Essentially what the formants and their magnitudes are
magRule=magnitudeRule(formantMagMatrix,numWindows);%[GB]Gets the rule based on magnitude
%freqRule=FreqDecisionRule(formantMagMatrix);%[GB] Gets the decision based on frequency
%finalAnswer=magRule&freqRule %[GB] ANDS the two results

%[GB] Point-wise multiplies the formantMagMatrix to get rid of all the
%windows that definitely do not have a vowel
for row=1:numWindows
formantMagMatrix(row,:)=magRule(row).*formantMagMatrix(row,:);
end
%formantMagMatrix
finalAnswer=formantMagMatrix;%[GB] Outputs the answer\
%[GB] Removes all the zero rows in the formantMagMatrix
j = [];%[GB] Creates a temp variable to hold the empty matrix
for i = 1:numWindows
    if (formantMagMatrix(i,:) ~= [0 0 0 0])
        j = [j; formantMagMatrix(i,:)];
    end
end
formantMagMatrix=j;%[GB]Reassigns the formantMatrix to the new one
newSize=size(formantMagMatrix);%[GB] Gets the new size of the formantMagMatrix that has all its non zero entries

%[GB]Instantiates the average f1 and f2 formant frequency values for the
%speaker
templatef1=[266.94 443.0366667 467.7666667 578.94 779.31 749.9266667 692.5233333 449.14 472.86 301.7033333 615.7066667 460.0566667]';
templatef2=[2437.073333 2028.343333 2207.166667 1914.47 1758.47 1089.986667 968.2466667 1206.583333 1020.103333 849.0766667 1139.403333 1291.533333]';
vowelCharacters=['i','I','e','E','A','0','a','U','o','u','Y','3'];%[GB] Takes the templates and makes a guess based of what the possible
f1PossibleVowels=zeros(1,12);%[GB]Creates a vector that holds the sum of the deltas between all the f1 formant frequencies and the template formant frequencies
f2PossibleVowels=zeros(1,12);%[GB]Creates a vector that holds the sum of the deltas between all the f2 formant frequencies and the template formant frequencies
%[GB]Percent errors for both formants
f1PercentError=zeros(1,newSize(1));
f2PercentError=zeros(1,newSize(1));
%vowels are
for vowel=1:12
    %[GB]Finds the minimum distance between the vowel formant frequencies
    %and the formants found in the audio sample
    %[nearestf1VowelFreq,nearestf1VowelIndex]=find_value_nearest(formantMagMatrix(:,1),templatef1(1,vowel));%[GB] Gets the closest f1 formant frequency to each vowel
    %[nearestf2VowelFreq,nearestf2VowelIndex]=find_value_nearest(formantMagMatrix(:,2),templatef2(1,vowel));%[GB] Gets the closest f2 formant frequency to each vowel
    for formant=1:newSize
        %[GB] Aggregrates the differences between the speaker's 
        %template f1 & f2 frequencies and the frequency of the actual
        %formants found
        %f1PercentError(formant)=(templatef1(vowel)-formantMagMatrix(formant,1))/templatef1(vowel);
        %f2PercentError(formant)=(templatef2(vowel)-formantMagMatrix(formant,2))/templatef2(vowel);
        f1PossibleVowels(vowel)=f1PossibleVowels(vowel)+abs(templatef1(vowel)-formantMagMatrix(formant,1));
        f2PossibleVowels(vowel)=f2PossibleVowels(vowel)+abs(templatef2(vowel)-formantMagMatrix(formant,2));
        
    end
end

finalResult=f1PossibleVowels+f2PossibleVowels;%[GB]Adds the two vectors 
[~,vowelIndex]=min(finalResult);%[GB]Grabs the index that has the smallest aggregrate differences between the f1 and f2 formant frequencies
finalAnswer=vowelCharacters(vowelIndex);%[GB] Returns the vowel character guess

finalPercentErrors=zeros(1,2);%[GB]Will hold the averaged percent errors for both formants
%[GB] Gets the average percent error for the chosen vowel
%finalPercentErrors(1,1)=f1PossibleVowels(1,vowelIndex)/(templatef1(vowelIndex)*newSize(1));
%finalPercentErrors(1,2)=f2PossibleVowels(1,vowelIndex)/(templatef2(vowelIndex)*newSize(1));

%[GB] Gets the percent error of the frequencies of the actual vowel in
%comparison to the speaker's template vowel frequencies
actualVowelIndex=findstr(vowelCharacters,actualVowel);%[GB] Finds the index for the actual vowel to aid getting the percent error calculation
finalPercentErrors(1,1)=f1PossibleVowels(1,actualVowelIndex)/(templatef1(actualVowelIndex)*newSize(1));
finalPercentErrors(1,2)=f2PossibleVowels(1,actualVowelIndex)/(templatef2(actualVowelIndex)*newSize(1));

percentError=mean(finalPercentErrors);%[GB] Gets the average percent error of the percent errors of each formant for the audio vowel sample
    


end