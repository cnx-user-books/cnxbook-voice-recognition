function possibleVowels = magnitudeRule(formantMagnitudeMatrix,numWindows )
%Code by Gbenga Badipe
%  Flags for possible vowels in each window of a DFT%
%  Returns a 1xNumWindow vector with values of 1's and 0's.
%  One being there is a possible vowel in this window
%  Zero being there is definitely not a vowel in this window

fmMatrix=formantMagnitudeMatrix;%[GB] Assigns the formant and magnitude matrix to a fmMatrix
possibleVowels=ones(1,numWindows);%[GB] Creates the result matrix as the size of the number of windows and sets all the entries to one
%f1MagMean=mean(fmMatrix(:,3));%[GB]Finds the mean of the first formant's magnitude
%f2MagMean=mean(fmMatrix(:,4));%[GB] Finds the mean of the second formant's magnitude
f1MaxMag=max(fmMatrix(:,3));%[GB] Finds the max magnitude of the first formant
f2MaxMag=max(fmMatrix(:,4));%[GB] Finds the max magnitude of the second formant
stdDeviation=std(fmMatrix);%[GB] Gets the standard deviation of the formant matrix

%%[GB]Remove all frequencies that will definitely not have a vowel%%
for window=1:numWindows
formantOne=fmMatrix(window,1);%[GB]Grabs the formant one's frequency value
formantTwo=fmMatrix(window,2);%[GB]Grabs the formant two's frequency value
formantOneMag=fmMatrix(window,3);%[GB]Grabs formant one's magnitude
formantTwoMag=fmMatrix(window,4);%[GB]Grabs formant two's magnitude value

%[GB]Check the frequencies and set it to zero if they fail the formant test
if(formantOne <= 200 || formantOne >=3500 || formantTwo<=200 ||formantTwo >= 3500)
    possibleVowels(1,window)=0;
end
%[GB]Check that the magnitudes are close to the formants' mean, if they are
%not, they are set to zero
if(abs(formantOneMag-f1MaxMag) > 2*stdDeviation(3))
    possibleVowels(1,window)=0;
end
if(abs(formantTwoMag-f2MaxMag) > 2*stdDeviation(4))
    possibleVowels(1,window)=0;
end

end


end

