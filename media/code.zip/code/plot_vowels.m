clear all
clc
tic
heed_listing  = dir('adrian_exported\*_heed.wav');
hid_listing   = dir('adrian_exported\*_hid.wav');
hayed_listing = dir('adrian_exported\*_hayed.wav');
head_listing  = dir('adrian_exported\*_head.wav');
had_listing   = dir('adrian_exported\*_had.wav');
hod_listing   = dir('adrian_exported\*_hod.wav');
hawed_listing = dir('adrian_exported\*_hawed.wav');
hood_listing  = dir('adrian_exported\*_hood.wav');
hoed_listing  = dir('adrian_exported\*_hoed.wav');
whood_listing = dir('adrian_exported\*_whood.wav');
hudd_listing  = dir('adrian_exported\*_hudd.wav');
heard_listing = dir('adrian_exported\*_heard.wav');

%Order goes 1 is adrian, 2 is alex, 3 is ben...alphabetical
all_listings = {heed_listing hid_listing hayed_listing head_listing had_listing  hod_listing  hawed_listing hood_listing hoed_listing whood_listing hudd_listing heard_listing};


fs = 1024;
error_matrix=[];
vowelCharacters=['i','I','e','E','A','0','a','U','o','u','Y','3'];
names = {'adrian','alex','ben'};

for this_listing_index = 1:length(all_listings)
    
    this_row = zeros(1,3);
    for this_person = 1:3
        
        this_file_name = ['adrian_exported\' all_listings{this_listing_index}(this_person).name];
        
        [~,percentError,finalAnswer] = formants(this_file_name,1024,vowelCharacters(this_listing_index));
        
        disp({percentError,vowelCharacters(this_listing_index),finalAnswer,names{this_person}})
        this_row(this_person) = (percentError);
        
    end
    error_matrix = [error_matrix;this_row];
    
end
figure
bar(error_matrix);
legend('Adrian','Alex','Ben');
xlabel('Vowels');
ylabel('Percent Error');

avg_errors = [mean(error_matrix(:,1)) mean(error_matrix(:,2)) mean(error_matrix(:,3))];

[~,min_index]=min(avg_errors);

name_cells = {'Adrian','Alex','Ben'};



msgbox(strcat(name_cells{min_index},' wins'))
disp(strcat(name_cells{min_index},' wins'))
avg_errors


toc
%set(gca,'XTickLabel',vowelCharacters);